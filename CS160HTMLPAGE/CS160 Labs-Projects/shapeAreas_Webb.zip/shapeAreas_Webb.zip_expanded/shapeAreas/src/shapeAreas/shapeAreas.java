package shapeAreas;

public class shapeAreas {
	//takes parameter radius and calculates area of circle with given radius
	public static double circleArea(double radius) {
		return radius*radius*Math.PI;
	}
	
	//takes parameters length and width and uses them to calculate area of rectangle of given dimensions
	public static double rectangleArea(double length, double width) {
		return length*width;
	}
	
	//takes parameters radius and height to calculate area of cylinder with given dimensions
	public static double cylinderArea(double radius, double height) {
		return radius*radius*height*Math.PI;
	}
}
