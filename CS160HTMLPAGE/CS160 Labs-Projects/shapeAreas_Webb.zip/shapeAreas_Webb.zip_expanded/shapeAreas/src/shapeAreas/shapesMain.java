package shapeAreas;
/*
 * Author: Davis Webb
 * Title: Lab 10 Programming Assignment (Problem 1)
 * Email: webbdm01@pdw.edu
 * Date: April 21, 2025
 * Description: defines methods that calculate area of circle, rectangle, and cylinder and demonstrates these methods
 */
public class shapesMain {
	public static void main (String[] args) {
		//Tests circleArea function and prints result
		System.out.println("Area of Circle with Radius 5.0: " + shapeAreas.circleArea(5.0));
		//Tests rectangleArea function and prints result
		System.out.println("\nArea of Rectangle 4.0 x 6.0: " + shapeAreas.rectangleArea(4.0, 6.0));
		//tests cylinderArea function and prints result
		System.out.println("\nArea of cylinder with radius 3.0 and height 10.0: " + shapeAreas.cylinderArea(3.0, 10.0));
	}
}
