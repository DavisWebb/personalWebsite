/**
 * 
 */
/**
 * 
 */
module shapeAreas {
}