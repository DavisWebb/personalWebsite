/* 1. Davis Webb
 * 2. webbdm01@pfw.edu
 * 3. 1/14/25
 * 4. HelloWorld
 * 5. Prints "Hello World" to console.
 */
package helloWorld;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");

	}

}
