package carpetCost;

public class carpetCalculations {
	//instantiates private fields necessary for class functionality
	private static double length = 0.0;
	private static double width = 0.0;
	private static double costPerSqFt = 0.0;
	
	//methods to set values of fields below
	public static void setLength(double newVal) {
		length = newVal;
	}
	
	public static void setWidth(double newVal) {
		width = newVal;
	}
	
	public static void setCost(double newVal) {
		costPerSqFt = newVal;
	}
	
	//calculates area of the room
	public static double getArea() {
		return length*width;
	}
	
	//calculates cost of carpet total based on room area and cost per square feet
	public static double findTotalCost() {
		return getArea()*costPerSqFt;
	}
}

