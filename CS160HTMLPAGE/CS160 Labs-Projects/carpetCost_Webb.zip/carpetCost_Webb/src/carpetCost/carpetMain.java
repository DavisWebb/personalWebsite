/*
 * Author: Davis Webb
 * Title: Lab 10 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Date: April 21, 2025
 * Description: Takes user input of carpet cost per square foot and room dimensions and calculates total cost 
 */
package carpetCost;
import java.util.Scanner;
public class carpetMain {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		//asks user for length of room and uses set method to set field in carpetCalculations.java
		System.out.println("Enter Room Length: ");
		double lengthInput = myScanner.nextDouble();
		carpetCalculations.setLength(lengthInput);
		myScanner.nextLine();
		//asks user for width of room and uses set method to set field in carpetCalculations.java
		System.out.println("Enter Room Width: ");
		double widthInput = myScanner.nextDouble();
		carpetCalculations.setWidth(widthInput);
		myScanner.nextLine();
		//asks for cost of carpet per square foot and uses set method to set field in carpetCalculations.java
		System.out.println("Enter cost per square foot: ");
		double cpsfInput = myScanner.nextDouble();
		carpetCalculations.setCost(cpsfInput);
		myScanner.nextLine();
		//close scanner since we are done with it
		myScanner.close();
		//finds total cost based on given inputs that were set to fields in carpetCalculations.java
		System.out.println("Total Carpet Cost: $" + carpetCalculations.findTotalCost());
	}

}
