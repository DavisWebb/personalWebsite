/*
 * Author: Davis Webb
 * Title: Lab 8 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Date: 3/31/25
 * Description: method that returns a distance in meters an object has fallen in a given time frame
 */
package fallDistance;

public class fallDistance {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {
			System.out.println("Time: " + i + "s  Distance: " + fallingDistance(i) + " meters");
		}
	}
	public static double fallingDistance(double time) {
		double distance = Math.pow(time,  2);
		distance *= 9.8;
		distance /= 2;
		distance *= 100;
		distance = Math.round(distance);
		distance /= 100;	
		return distance;
	}

}
