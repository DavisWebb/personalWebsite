/*
 * Author: Davis Webb
 * Title Lab 2 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Date: February 9th, 2025
 * Description: program that calculates customer's monthly internet service bill
 */
package serviceProvider;
import java.util.Scanner;
public class serviceProvider {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Internet Service Subscription Plans:\n1: $9.95/month, 10 hours, $2 per additional hour\n2: $13.95/month, 20 hours, $1 per additional hour\n3: $19.95/month, unlimited access.\n\nEnter the package number (1, 2, or 3): ");
		int choice = myScanner.nextInt();
		System.out.print("You've selected option: " + choice + ". How many hours were used this month? ");
		int hours = myScanner.nextInt();
		int bonusHours;
		double charge;
		if (choice == 1 && hours <= 10) {
			charge = 9.95;
		}
		else if (choice == 1 && hours > 10) {
			charge = 9.95;
			bonusHours = hours-10;
			charge += (bonusHours*2);
		}
		else if (choice == 2 && hours <= 20) {
			charge = 13.95;
		}
		else if (choice == 2 && hours > 20) {
			charge = 13.95;
			bonusHours = hours-20;
			charge += bonusHours;
		}
		else {
			charge = 19.95;
		}
		System.out.print("Your Total Monthly Charge is: " + charge);

	}

}
