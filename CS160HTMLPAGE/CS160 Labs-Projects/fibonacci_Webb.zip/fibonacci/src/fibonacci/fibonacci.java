/*
 * Author: Davis Webb
 * Title: Lab 4 Programming Assignment (Problem 1)
 * Email: webbdm01@pfw.edu
 * Date: February 23, 2025
 * Description: Program outputs the first n (inserted by user) terms of the Fibonacci sequence.
 */
package fibonacci;
import java.util.Scanner;
public class fibonacci {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter the number of terms: ");
		int previous = 1;
		int temp = 0;
		int n = myScanner.nextInt();
		int fib = 0;
		System.out.print("Fibonacci Sequence: ");
		for (var i = 0; i < n; i++) {
			System.out.print(fib + " ");
			temp = fib;
			fib += previous;
			previous = temp;
		}
		myScanner.close();
	}

}
