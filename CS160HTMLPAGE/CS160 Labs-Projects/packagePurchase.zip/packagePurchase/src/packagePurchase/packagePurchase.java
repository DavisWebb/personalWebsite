/*
 * Author: Davis Webb
 * Title: Lab 2 Programming Assignment (Problem 1)
 * Email: webbdm01@pfw.edu
 * Date: February 9th, 2025
 * Description: program that calculates the discount applied and subsequent price of purchasing a specified number of packages
 */
package packagePurchase;
import java.util.Scanner;
public class packagePurchase {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("How many packages would you like to purchase?");
		int numPurchased = myScanner.nextInt();
		double price = 99*numPurchased;
		double discountMultiple;
		if (numPurchased < 10) {
			discountMultiple = 1.00;
		}
		else if (numPurchased < 20) {
			discountMultiple = 0.80;
		}
		else if (numPurchased < 50) {
			discountMultiple = 0.70;
		}
		else if (numPurchased < 100) {
			discountMultiple = 0.60;
		}
		else {
			discountMultiple = 0.50;
		}
		double priceTwo = price*discountMultiple;
		double discount = price-priceTwo;
		System.out.println("Since you purchased " + numPurchased + " packages, you get a discount of: $" + discount + "\nThe final price for " + numPurchased + " packages with all applicable discounts is: $" + priceTwo);
		myScanner.close();
	}

}
