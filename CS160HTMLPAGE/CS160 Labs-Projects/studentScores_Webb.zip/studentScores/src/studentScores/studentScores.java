/*Author: Davis Webb
 *Title: Project 2 Programming Assignment
 *Email: webbdm01@pfw.edu
 *Date: March 31, 2025
 *Description: Program takes student names and scores and outputs many variables like the average score, highest score, students responsible for highest score, etc 
 */
package studentScores;
import java.util.Scanner;
public class studentScores {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.println("Enter number of students: ");
		int numStudents = myScanner.nextInt();
		int[] scores = new int[numStudents];
		String[] names = new String[numStudents];
		for (int i = 1; i <= numStudents; i++) {
			myScanner.nextLine();
			System.out.println("Enter the name of student " + i + ": ");
			names[i-1] = myScanner.nextLine();
			scores[i-1] = -1;
			while (scores[i-1] < 1 || scores[i-1] > 100) {
				System.out.println("Enter the score for " + names[i-1] + ": ");
				scores[i-1] = myScanner.nextInt();
				if (scores[i-1] < 1 || scores[i-1] > 100) {
					System.out.println("Score must be between 1 and 100. Please try again.\n\n");
				}
			}
		}
		myScanner.close();
		int[] unsortedScores = new int[numStudents];
		for (int s = 0; s < numStudents; s++) {
			unsortedScores[s] = scores[s];
		}
		scores = sortList(scores);
		int medianIndex = 0;
		double trueMedian;
		if (scores.length % 2 == 1) {
			medianIndex = scores.length/2;
			trueMedian = scores[medianIndex];
		}
		else {
			int med1 = scores.length/2;
			int med2 = scores.length/2 - 1;
			trueMedian = scores[med1] + scores[med2];
			trueMedian = trueMedian/2;
		}
		double sum = 0.0;
		double average = 0.0;
		for (int p = 0; p < scores.length; p++) {
			sum += scores[p];
		}
		average = sum/scores.length;
		double min = scores[0];
		double max = scores[scores.length - 1];
		System.out.println("\n\n-----Statistics-----\n\nAverage Score: " + average + "\nMedian Score: " + trueMedian + "\nHighest Score: " + max + "\nLowest Score: " + min);
		System.out.print("\nTop Scorer(s): ");
		int numMax = 0;
		int numAboveAvg = 0;
		int numBelowAvg = 0;
		names = sortStrings(unsortedScores, names);
		for (int o = 0; o < scores.length; o++) {
			if (scores[o] == max) {
				numMax++;
				if (numMax > 1) {
				System.out.print(", " + names[o]);
				}
				else {
					System.out.print(names[o]);
				}
			}
			if (scores[o] > average) {
				numAboveAvg++;
			}
			else if (scores[o] < average) {
				numBelowAvg++;
			}
		}
		System.out.println("\n\nNumber of students above average: " + numAboveAvg + "\nNumber of students below average: " + numBelowAvg + "\n\n-----Ranking (High to Low)-----");
		int a = 0;
		for (int b = names.length - 1; b >= 0; b--) {
			a++;
			System.out.println("\n" + a + ". " + names[b] + " - " + scores[b]);
		}
	}
		public static int[] sortList(int[] list) {
			int temp = list[0];
			for (int i = 0; i < list.length - 1; i++) {
				for (int e = i; e < list.length; e++) 	{
					if (list[e] < list[i]) {
						temp = list[i];
						list[i] = list[e];
						list[e] = temp;
					}
				}
			}
			return list;
		}
		public static String[] sortStrings(int[] list1, String[] names) {
			String temp = "";
			int intTemp = 0;
			for (int i = 0; i < list1.length - 1; i++) {
				for (int e = i; e < list1.length; e++) 	{
					if (list1[e] < list1[i]) {
						intTemp = list1[i];
						list1[i] = list1[e];
						list1[e] = intTemp;
						temp = names[i];
						names[i] = names[e];
						names[e] = temp;
					}
				}
			}
			return names;
		}
}
