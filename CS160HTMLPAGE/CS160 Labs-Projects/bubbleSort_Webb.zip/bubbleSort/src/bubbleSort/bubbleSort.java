/*
 * Author: Davis Webb
 * Title: Lab 7 Programming Assignment
 * Email: webbdm01
 * Date: March 24, 2025
 * Description: sorts a given list of integers
 */
package bubbleSort;
import java.util.Scanner;

public class bubbleSort {
	public static void main(String[] Args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter array size: ");
		int size = myScanner.nextInt();
		myScanner.nextLine();
		System.out.print("Enter Elements (ensure there is no extra space at the start of list): ");
		String userNums = myScanner.nextLine();
		int spaceIndex = 0;
		int[] list = new int[size];
		String currentString;
		for (int i = 0; i < size; i++) {
			if (userNums.substring(0, 1).equals(" ")) {
				userNums = userNums.substring(1, userNums.length());
			}
			if (userNums.indexOf(" ") != -1) {
			spaceIndex = userNums.indexOf(" ");
			currentString = userNums.substring(0, spaceIndex);
			list[i] = Integer.parseInt(currentString);
			userNums = userNums.substring(spaceIndex + 1, userNums.length());
			}
			else if (list.length > 0) {
				list[i] = Integer.parseInt(userNums.substring(0, userNums.length())); 
			}
		}
		int temp = list[0];
		for (int e = 0; e < size - 1; e++) {
			for (int o = e; o < size; o++) {
				if (list[o] < list[e]) {
					temp = list[o];
					list[o] = list[e];
					list[e] = temp;
				}
			}
		}
		System.out.print("sorted array: ");
		for (int n = 0; n < size; n++) {
			System.out.print(list[n] + " ");
		}
		myScanner.close();
	}
}
