/*
 * Author: Davis Webb
 * Title: Lab 8 Programming Assignment (Problem 1)
 * Email: webbdm01@pfw.edu
 * Date: 3/31/25
 * Description: gives retail price based on wholesale cost and markup %
 */
package retailPrice;
import java.util.Scanner;
public class retailPrice {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		double retailPrice = 0.0;
		System.out.println("What is the wholesale cost? ");
		double wholesale = myScanner.nextDouble();
		System.out.println("What is the markup %? ");
		double markup = myScanner.nextDouble();
		markup /= 100;
		markup += 1;
		retailPrice = wholesale*markup;
		System.out.println("Retail Price: " + retailPrice);
		myScanner.close();

	}

}
