/*
 * Author: Davis Webb
 * Title: Lab 4 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Date: February 23, 2025
 * Description: calculates the value of pi using Leibniz formula at a precision given by user
 */
package leibniz;
import java.util.Scanner;
public class leibniz {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("How many terms of precision would you like to calculate the value of pi at: ");
		int input = myScanner.nextInt();
		myScanner.nextLine();
		int denom = 3;
		double frac = 0.0;
		double result = 4;
		double active = 1;
		for (int i = 0; i < input-1; i++) {
			if (i % 2 == 0) {
				frac = 1.0;
				frac /= denom;
				active -= frac;
			}
			else {
				frac = 1.0;
				frac /= denom;
				active += frac;
			}
			denom += 2;
		}
		result *= active;
		System.out.print("Approximated Value of Pi: " + result);
		myScanner.close();

	}

}
