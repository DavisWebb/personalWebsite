/*Author: Davis Webb
 * Title: Lab One Programming Assignment Problem 1
 * Date: January 28th, 2025
 * Description: Program that calculates age of given user 10 years in the future, 20 years in the future, 
 * 40 years in the future, and a specified (yearsForward) amount of years in the future.
 */
package labOnee;
import java.util.Scanner;
public class labOnee{

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.println("Hi there, welcome to lab 2!\n");
		System.out.println("How Old Are You? ");
		int startAge = myScanner.nextInt();
		System.out.println("How far in the future would you like to time travel? (in years) ");
		int yearsForward = myScanner.nextInt();
		int endAge = yearsForward+startAge;
		int plusTen = startAge+10;
		int plusTwenty = startAge+20;
		int plusForty = startAge+40;
		System.out.println("in 10 years you will be " + plusTen + " years old.\nIn 20 years you will be " + plusTwenty + " years old.\nIn 40 years you will be " + plusForty + " years old.\nIf you travel " + yearsForward + " years into the future, you will be " + endAge + " years old.");
	}

}
