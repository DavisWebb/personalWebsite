/**
 * 
 */
/**
 * 
 */
module labOne {
}