package labOne;

public class labOne {

}
