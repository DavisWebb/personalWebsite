/*
 * Author: Davis Webb
 * Title: Lab 6 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Description: Gives average, min, max, and sum of all numbers in a list
 */
package listProperties;
import java.util.Scanner;

public class listProperties {
	public static void main(String[] Args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter the amount of numbers you would like to have in the list: ");
		int count = myScanner.nextInt();
		double[] list = new double[count];
		System.out.print("Now what would you like those " + count + " numbers to be? Seperate them by spaces, not commas please: ");
		myScanner.nextLine();
		String userNums = myScanner.nextLine();
		int spaceIndex = 0;
		String currentString;
		for (int i = 0; i < count; i++) {
			if (userNums.indexOf(" ") != -1) {
				spaceIndex = userNums.indexOf(" ");
				currentString = userNums.substring(0, spaceIndex + 1);
				list[i] = Double.parseDouble(currentString);
				userNums = userNums.substring(spaceIndex + 1, userNums.length());
			} 
			else if (list.length > 0) {
				list[i] = Double.parseDouble(userNums.substring(0, userNums.length())); 
			}
			
		}
		double min = list[0];
		double max = list[0];
		double average = 0;
		double sum = 0;
		for (int e = 0; e < list.length; e++) {
			if (list[e] < min) {
				min = list[e];
			}
			if (list[e] > max) {
				max = list[e];
			}
			sum += list[e];
		}
		average = sum / list.length;
		System.out.print("Min: " + min + "\nMax: " + max + "\nAverage: " + average + "\nSum: " + sum);
		myScanner.close();
	}
} 
