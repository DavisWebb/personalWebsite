/*
 * Author: Davis Webb
 * Title: Lab One Program Assignment (problem 2)
 * Date: January 28th, 2025
 * Description:
 */
package personalFinanceCalc;
import java.util.Scanner;
public class personalFinanceCalc {
	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.println("Welcome to the Personal Finance Calculator!\n\nEnter your monthly rent: ");
		double rent = myScanner.nextDouble();
		myScanner.nextLine();
		System.out.println("Enter your monthly utility bills: ");
		double utilities = myScanner.nextDouble();
		myScanner.nextLine();
		System.out.println("Enter your monthly grocery expenses: ");
		double groceries = myScanner.nextDouble();
		myScanner.nextLine();
		System.out.println("Enter your monthly income: ");
		double income = myScanner.nextDouble();
		myScanner.nextLine();
		double monthlySavings = income - rent - utilities - groceries;
		double totalExpenses = rent + utilities + groceries;
		System.out.println("\nYour total monthly expenses are: $" + totalExpenses + "\nYour total monthly savings are: $" + monthlySavings + "\nYou saved a lot of money! Congrats.");
	}
}
