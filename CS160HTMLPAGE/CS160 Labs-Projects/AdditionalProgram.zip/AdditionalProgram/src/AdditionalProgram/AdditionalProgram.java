/*1. Davis Webb
 *2. webbdm01@pfw.edu
 *3. 1/14/25
 *4. AdditionalProgram
 *5. Adds two numbers inputted  by user together.
 */
package AdditionalProgram;
import java.util.Scanner;

public class AdditionalProgram {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.println("Enter The First Number: ");
		int first = myScanner.nextInt();
		System.out.println("Enter The Second Number: ");
		int second = myScanner.nextInt();
		int result = first + second;
		System.out.println("The Sum of " + first + " and " + second + " is " + result);
	} 

}
