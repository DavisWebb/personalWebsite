/**
 * 
 */
/**
 * 
 */
module propertiesOfNumbers {
}