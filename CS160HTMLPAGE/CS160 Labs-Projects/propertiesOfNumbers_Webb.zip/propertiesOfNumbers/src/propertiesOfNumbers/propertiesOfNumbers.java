/*
 * Author: Davis Webb
 * Title: Project 1 (Properties of Numbers)
 * Email: webbdm01@pfw.edu
 * Date: 2/26/25
 * Description: program that outputs the properties (prime, factors, factorial, etc) of a given number
 */
package propertiesOfNumbers;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashSet;
public class propertiesOfNumbers {

	public static void main(String[] args) {
		String prime;
		String evenOdd;
		double sqrt;
		double pow;
		int digitSum = 0;
		String palindrome;
		ArrayList<Integer> factors = new ArrayList<Integer>();
		Scanner myScanner = new Scanner(System.in);
		System.out.print("What number would you like the properties of? ");
		int choice = myScanner.nextInt();
		sqrt = Math.sqrt(choice);
		pow = Math.pow(choice,  2);
		if (choice % 2 == 0) {
			evenOdd = "Even";
		}
		else {
			evenOdd = "Odd";
		}
		String choiceString = Integer.toString(choice);
		String palindromeCheck = "";
		for (int i = choiceString.length(); i > 0; i--) {
			palindromeCheck += choiceString.substring(i-1, i);
		}
		if (palindromeCheck.equals(choiceString)) {
			palindrome = "Yes";
		}
		else {
			palindrome = "No";
		}
		ArrayList<String> digits = new ArrayList<String>();
		String p = Integer.toString(choice);
		for (int e = 0; e < p.length(); e++) {
			digits.add(p.substring(e, e + 1));
		}
		System.out.println(digits);
		for (int o = 0; o < digits.size(); o++) {
			digitSum += Integer.valueOf(digits.get(o));
		}
		for (int n = 0; n <= choice; n++) {
			for (int k = 0; k <= choice; k++) {
				if (choice == n * k) {
					factors.add(k);
					factors.add(n);
				}
			}
		}
		HashSet<Integer> factorSet = new HashSet<Integer>(factors);
		factors.clear();
		factors.addAll(factorSet);
		if (factors.size() <= 2) {
			prime = "Yes";
		}
		else {
			prime = "No";
		}
		System.out.print("\nNumber: " + choice + "\nEven/Odd: " + evenOdd + "\nPrime: " + prime + "\nSquare: " + pow + "\nSquare Root: " + sqrt + "\nSum of Digits: " + digitSum + "\nFactors: " + factors + "\nPalindrome: " + palindrome);
		myScanner.close();

	}

}
