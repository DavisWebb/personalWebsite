/*
 * Author: Davis Webb
 * Title: Lab 6 Programming Assignment (Problem One)
 * Email: webbdm01@pfw.edu
 * Date: March 23, 2025
 * Description: Takes an integer input and determines if it is part of a predetermined list of account numbers
 */
package validAccounts;
import java.util.Scanner;

public class validAccounts {
	public static void main(String[] Args) {
		int[] validAccounts = new int[] {5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 8080152, 4562555,
			5552012, 5050552, 7825877, 1250255, 1005231, 6545231, 3852085, 7576651,
			7881200, 4581002};
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter your account number: ");
		int user = myScanner.nextInt();
		boolean found = false;
		for (int i = 0; i < validAccounts.length; i++) {
			if (validAccounts[i] == user) {
				found = true;
			}
		}
		if (found == true) {
			System.out.println("Valid Account Number");
		}
		else {
			System.out.println("Invalid Account Number");
		}
		myScanner.close();
	}
}
