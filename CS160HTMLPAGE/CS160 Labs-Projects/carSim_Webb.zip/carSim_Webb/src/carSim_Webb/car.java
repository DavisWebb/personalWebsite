package carSim_Webb;

public class car {
	private String make;
	private int model;
	private int speed;
	public car(String make, int model) {
		this.make = make;
		this.model = model;
		this.speed = 0;
	}
	public void accelerate() {
		speed += 5;
		return;
	}
	public void brake() {
		speed -= 5;
		return;
	}
	public String getMake() {
		return make;
	}
	public int getModel() {
		return model;
	}
	public int getSpeed() {
		return speed;
	}
}
