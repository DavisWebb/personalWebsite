/*
 * Author: Davis Webb
 * Title: Lab 9 Programming Assignment (Problem 1)
 * Email: webbdm01@pfw.edu
 * Date: April 11th, 2025
 * Description: lists stats of car and then prints speeds during acceleration and braking
 */
package carSim_Webb;

public class carMain_Webb {
	public static void main(String Args[]) {
		car newCar = new car("BMW", 2013);
		System.out.println("Make: " + newCar.getMake());
		System.out.println("Model: " + newCar.getModel());
		for (int i = 0; i < 5; i++) {
			newCar.accelerate();
			System.out.println("Speed After Accelerating: " + newCar.getSpeed());
		}
		for (int e = 0; e < 5; e++) {
			newCar.brake();
			System.out.println("Speed After Braking: " + newCar.getSpeed());
		}
	}
}
