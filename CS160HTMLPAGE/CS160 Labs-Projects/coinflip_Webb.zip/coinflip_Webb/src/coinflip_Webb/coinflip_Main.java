/*
 * Author: Davis Webb
 * Title: Lab 9 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Date: April 11th, 2025
 * Description: flips coin 20 times then gives result totals
 */
package coinflip_Webb;

public class coinflip_Main {

	public static void main(String[] args) {
		Coin newCoin = new Coin();
		newCoin.flipCoin(20);
	}

}
