package coinflip_Webb;

public class Coin {
	private String sideUp;
	public Coin() {
		double ran = Math.random();
		if (ran > .5) {
			sideUp = "heads";
		}
		else {
			sideUp = "tails";
		}
	}
	public void flipCoin(int flips) {
		int heads = 0;
		int tails = 0;
		for (int i = 1; i < flips + 1; i++) {
		double random = Math.random();
			if (random > .5) {
				sideUp = "heads";
				heads++;
			}
			else {
				sideUp = "tails";
				tails++;
			}
			System.out.println("Toss " + i + ": " + getSideUp());
		}
		System.out.println("Total Heads: " + heads + "\nTotal Tails: " + tails);
	}
	public String getSideUp() {
		return sideUp;
	}
}