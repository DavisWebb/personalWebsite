/**
 * 
 */
/**
 * 
 */
module pennyDoubler {
}