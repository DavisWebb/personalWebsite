/*
 * Author: Davis Webb
 * Title: Lab 3 Programming Assignment (problem two)
 * Email: webbdm01@pfw.edu
 * Date: February 14th, 2025
 * Description: calculate total earnings starting at one penny and doubling every day for a specified number of days
 */
package pennyDoubler;
import java.util.Scanner;
public class pennyDoubler {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter number of days worked: ");
		int days = myScanner.nextInt();
		double dollars = 0.01;
		int count = 0;
		for (int i = 0; i < days; i++) {
			count = i + 1;
			System.out.println("Day " + count + " earning = $" + dollars);
			dollars *= 2;
		}
		System.out.println("Total pay after " + days + " days = $" + dollars);
		myScanner.close();
	}

}
