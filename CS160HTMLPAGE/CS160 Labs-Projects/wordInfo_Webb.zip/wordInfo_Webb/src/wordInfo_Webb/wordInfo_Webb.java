/*
 * Author: Davis Webb
 * Title: Lab 5 Programming Assignment (problem 1)
 * Email: webbdm01@pfw.edu
 * Date: March 9th, 2025
 * Description: gives user info about a specified word
 */
package wordInfo_Webb;
import java.util.Scanner;
public class wordInfo_Webb {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter a word: ");
		String choice = myScanner.next();
		String lower = choice.toLowerCase();
		String upper = choice.toUpperCase();
		int length = choice.length();
		System.out.println("\nUppercase: " + upper + "\nLowercase: " + lower + "\nLength: " + length + "\nFirst Character: " + choice.substring(0, 1) + "\nLast Character: " + choice.substring(choice.length() - 1, choice.length()));
		myScanner.close();

	}

}
