/*
 * Author: Davis Webb
 * Title: Lab 3 Programming Assignment (Problem One)
 * Email: webbdm01@pfw.edu
 * Date: February 14th, 2025
 * Description: outputs the factorial of the input
 */
package factorial2;
import java.util.Scanner;
public class factorial2 {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter a positive nonzero integer: ");
		int input = myScanner.nextInt();
		int result = 0;
		for (int i = 0; i <= input; i++) {
			result += i;
		}
		System.out.print("the sum of integers 1 through " + input + " is: " + result);
		

	}

}
