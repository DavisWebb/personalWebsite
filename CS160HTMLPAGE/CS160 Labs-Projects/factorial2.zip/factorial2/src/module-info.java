/**
 * 
 */
/**
 * 
 */
module factorial2 {
}