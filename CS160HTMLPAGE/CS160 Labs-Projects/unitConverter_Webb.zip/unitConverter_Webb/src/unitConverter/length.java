package unitConverter;

public class length {
	private static int fToM = 0;
	private static int mToF = 0;
	//converts feet to meters (1 foot = 0.3048 meters)
	public static double feetToMeters(double feet) {
		fToM++;
		return feet*0.3048;
	}
	//converts meters to feet (1 meter = 3.28084 feet)
	public static double metersToFeet(double meters) {
		mToF++;
		return meters*3.28084;
	}
	public static int getMToF() {
		return mToF;
	}
	public static int getFToM() {
		return fToM;
	}
}
