package unitConverter;

public class temp2 {
	private static int fToC = 0;
	private static int cToF = 0;
	//converts farenheit to celsius (formula is (F-32)*5/9=C)
	public static double farenheitToCelsius(double farenheit) {
		double result = farenheit-32;
		result *= 5;
		result /= 9;
		fToC++;
		return result;
	}
	//converts celsius to farenheit using inverse of previous formula
	public static double celsiusToFarenheit(double celsius) {
		double result = celsius*9;
		result /= 5;
		result +=32;
		cToF++;
		return result;
	}
	public static int getCToF() {
		return cToF;
	}
	public static int getFToC() {
		return fToC;
	}
}
