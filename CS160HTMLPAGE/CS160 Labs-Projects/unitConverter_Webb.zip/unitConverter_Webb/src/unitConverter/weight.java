package unitConverter;

public class weight {
	private static int kgToLBS = 0;
	private static int lbsToKG = 0;
	//converts KG (kilograms) to LBS (pounds) (1 KG = 2.20462 LBS)
	public static double kgToLBS(double kg) {
		kgToLBS++;
		return kg*2.20462;
	}
	//converts LBS (pounds) to KG(kilograms) (1 pound = 0.453592 KG)
	public static double lbstoKG(double lbs) {
		lbsToKG++;
		return lbs*0.453592;
	}
	public static int getKGToLBS() {
		return kgToLBS;
	}
	public static int getLBSToKG() {
		return lbsToKG;
	}
}
