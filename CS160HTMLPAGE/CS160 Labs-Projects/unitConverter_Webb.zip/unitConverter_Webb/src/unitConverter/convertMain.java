/*
 * Author: Davis Webb
 * Title: Project 3 (Unit Converter)
 * Email: webbdm01@pfw.edu
 * Date: April 17, 2025
 * Description: Converts length, weight, and temperature between imperial and metric system according to user specification
 */
package unitConverter;
import java.util.Scanner;
public class convertMain {

	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		int choice = -1;
		int choice2 = -1;
		double inputVal = -1.0;
		//loop so that the program restarts instead of breaking if the user does not enter a valid input
		while (choice != 4) {
			System.out.print("---Welcome to the Unit Converter! Please input a number to select which units to convert!---\n1. Length (Meters <--> Feet)\n2. Weight (KG <--> Pounds)\n3. Temperature (C <--> F)\n4. Exit\nEnter your choice:");
			choice = myScanner.nextInt();
			myScanner.nextLine();
			//brings user to menu to convert length
			if (choice == 1) {
				//loop for if user enters invalid value
				while (choice2 != 1 && choice2 != 2) {
					System.out.print("You Selected Length!\n\n1. Meters to Feet\n2. Feet to Meters\n\nChoose Conversion:");
					choice2 = myScanner.nextInt();
					myScanner.nextLine();
					System.out.print("\nEnter Value:");
					inputVal = myScanner.nextDouble();
					myScanner.nextLine();
					//calculates input number of meters to number of feet using method in length.java
					if (choice2 == 1) {
						System.out.print("\n" + inputVal + " meters is equal to " + length.metersToFeet(inputVal) + " feet!\n\n");
					}
					//calculates input number of feet to number of meters using method in length.java
					else if (choice2 == 2) {
						System.out.print("\n" + inputVal + " feet is equal to " + length.feetToMeters(inputVal) + " meters!\n\n");
					}
					//if user did not input a proper value for choice2
					else {
						System.out.print("\nYou didnt input 1 or 2. Remember, 1 = meters to feet, 2 = feet to meters. Try again!\n\n");
					}
				}
				choice2 = -1;
			}
			//brings user to menu to convert weight
			else if (choice == 2) {
				while (choice2 != 1 && choice2 != 2) {
					System.out.print("You Selected Weight!\n\n1. Kilograms to Pounds\n2. Pounds to Kilograms\n\nChoose Conversion:");
					choice2 = myScanner.nextInt();
					myScanner.nextLine();
					System.out.print("\nEnter Value:");
					inputVal = myScanner.nextDouble();
					myScanner.nextLine();
					//calculates input number of kilograms to number of pounds using method in weight.java
					if (choice2 == 1) {
						System.out.print("\n" + inputVal + " Kilograms is equal to " + weight.kgToLBS(inputVal) + " Pounds!\n\n");
					}
					//calculates input number of pounds to number of kilograms using method in weight.java
					else if (choice2 == 2) {
						System.out.print("\n" + inputVal + " Pounds is equal to " + weight.lbstoKG(inputVal) + " Kilograms!\n\n");
					}
					//if user did not input a proper value for choice2
					else {
						System.out.print("\nYou didnt input 1 or 2. Remember, 1 = Kilograms to Pounds, 2 = Pounds to Kilograms. Try again!\n\n");
					}
				}
				choice2 = -1;
			}
			//brings user to menu to convert temperature
			else if (choice == 3) {
				while (choice2 != 1 && choice2 != 2) {
					System.out.print("You Selected Temperature!\n\n1. Celsius to Farenheit\n2. Farenheit to Celsius\n\nChoose Conversion:");
					choice2 = myScanner.nextInt();
					myScanner.nextLine();
					System.out.print("\nEnter Value:");
					inputVal = myScanner.nextDouble();
					myScanner.nextLine();
					//calculates input number of degrees celsius to number of degrees farenheit using method in temp2.java
					if (choice2 == 1) {
						System.out.print("\n" + inputVal + " Celsius is equal to " + temp2.celsiusToFarenheit(inputVal) + " Farenheit!\n\n");
					}
					//calculates input number of degrees farenheit to number of degrees celsius using method in temp2.java
					else if (choice2 == 2) {
						System.out.print("\n" + inputVal + " Farenheit is equal to " + temp2.farenheitToCelsius(inputVal) + " Celsius!\n\n");
					}
					//if user did not input a proper value for choice2
					else {
						System.out.print("\nYou didnt input 1 or 2. Remember, 1 = Celsius to Farenheit, 2 = Farenheit to Celsius. Try again!\n\n");
					}
				}
				choice2 = -1;
			}
			//shows user how many times they used each conversion then terminates if they choose to exit
			else if (choice == 4) {
				System.out.println("\n\nEnding Program. Here are your usage statistics: ");
				System.out.println("\nTemperature Conversion Count: \n-Farenheit To Celsius: " + temp2.getFToC() + "\n-Celsius To Farenheit: " + temp2.getCToF());
				System.out.println("\nWeight Conversion Count: \n-KG To LBS: " + weight.getKGToLBS() + "\n-LBS To KG: " + weight.getLBSToKG());
				System.out.println("\nLength Conversion Count: \n-Feet To Meters: " + length.getFToM() + "\n-Meters To Feet: " + length.getMToF());
				myScanner.close();
				System.exit(0);
			}
			//if choice is not one of the options listed, tells user and goes back to beginning of loop
			else {
				System.out.println("\n\nThis Input is not any listed above! Please try again. Remember, you can only choose 1, 2, 3, or 4\n\n");
			}
		}
		myScanner.close();
	}

}
