/*
 * Author: Davis Webb
 * Title: Lab 5 Programming Assignment (Problem 2)
 * Email: webbdm01@pfw.edu
 * Date: March 9th, 2025
 * Description: determines whether a specified word is a palindrome or not
 */
package palindrome_Webb;
import java.util.Scanner;
public class palindrome_Webb {
	public static void main(String[] args) {
		Scanner myScanner = new Scanner(System.in);
		System.out.print("Enter a word: ");
		String word = myScanner.next();
		int length = word.length();
		String[] letters = new String[length];
		String[] backwards = new String[length];
		int position = 0;
		for (int i = 0; i < length; i++) {
			position = length - i;
			backwards[i] = word.substring(position - 1, position);
			letters[i] = word.substring(i, i + 1);
		}
		boolean boo = true;
		String s1 = "";
		String s2 = "";
		for (int e = 0; e < length; e++) {
			s1 = letters[e];
			s2 = backwards[e];
			if (!s1.equals(s2)) {
				boo = false;
			}
		}
		System.out.print(word + " is a palindrome: " + boo);
		myScanner.close();
	}
}